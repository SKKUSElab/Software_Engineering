# Shoose
This repository contains Android Project of [Shoose]().

## To Contributors
Please fork first

Do not work with MASTER BRANCH, please.


## API
Uses NAVER API
