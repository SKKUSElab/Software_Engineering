<?php
$HostName = "ec2-54-180-31-90.ap-northeast-2.compute.amazonaws.com";
$HostUser = "asdf";
$HostPass = "1234";
$DatabaseName = "livedu";
?>
