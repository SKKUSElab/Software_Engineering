package com.example.jang.se;

public class StreamInformation {
    public static final String STREAM_URL="rtsp://192.168.17.1:1935/live/myStream";
    public static final String PUBLISHER_USERNAME = "JiHo_Jang";
    public static final String PUBLISHER_PASSWORD = "qw1qw1";
}
