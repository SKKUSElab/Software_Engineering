package com.example.mrhjs.ocha;

public class Recommand_data {
    String keyword;
    public String getKeyword() {
        return keyword;
    }
    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public Recommand_data(){}
}
