package com.example.mrhjs.ocha;

public class Find_Data {
    String f_id;
    String f_answer;
    String f_password;

    public String getF_id() {
        return f_id;
    }

    public void setF_id(String f_id) {
        this.f_id = f_id;
    }

    public String getF_answer() {
        return f_answer;
    }

    public void setF_answer(String f_answer) {
        this.f_answer = f_answer;
    }

    public String getF_password() {
        return f_password;
    }

    public void setF_password(String f_password) {
        this.f_password = f_password;
    }

    public Find_Data(){}
}
