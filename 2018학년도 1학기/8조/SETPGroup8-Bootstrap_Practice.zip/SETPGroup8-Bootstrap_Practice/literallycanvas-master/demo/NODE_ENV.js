var process = {
    env: {
        NODE_ENV: "development"
    }
};
