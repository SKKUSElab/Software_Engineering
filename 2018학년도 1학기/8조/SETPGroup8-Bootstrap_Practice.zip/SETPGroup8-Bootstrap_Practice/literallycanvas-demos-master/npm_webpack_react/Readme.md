# Literally Canvas + React + Webpack

To run:

```sh
npm install -g webpack
npm install
make serve
```

And navigate to `http://localhost:8000`.
