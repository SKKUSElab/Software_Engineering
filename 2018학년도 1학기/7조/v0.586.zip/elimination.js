/**
 * http://usejsdoc.org/
 */

module.exports= class elimination{
	constructor(query, UserList){
		this.query = query;
		this.UserList = UserList;
	}
	
	say(){
		return 1;
	}
	
	eliminate(eliminater, eliminatee){
		
		var UserList = this.UserList;
		var deadman;
		
		var e1;
		var e2;
		
		UserList.forEach(function(item, index, array){
			if(item.mem_id == eliminater.id){
				e1 = item;
			}
			if(item.mem_id == eliminatee.id){
				e2 = item;
			}
		})
		
		if(e2.role == "리더"){
			UserList.forEach(function(item, index, array){
				if(item.mem_id == eliminatee.id){
					item.isalive = false;
					deadman = item;
				}
			})
			return UserList, deadman;
		}
		else {
			UserList.forEach(function(item, index, array){
				//console.log(`item.id = ${item.id.toString()}, target = ${idtoid(eliminater.id)}`);
				if(item.mem_id == eliminater.id)
					item.isalive = false;
					deadman = item;
			})
			return UserList, deadman;
		}
	}
}

function idtoid(id){
	return "<@!" + id + ">";
}

