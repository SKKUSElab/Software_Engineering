const Discord = require('discord.js');
const client = new Discord.Client();
var apiai = require('apiai');
var config = require('./config');
const prefix = config.prefix;
var app = apiai(config.Dialogflow);
console.log(config);

var obj1 = new Object();
obj1 = {
    "id" : "232068651539365889",
    "team" : 'A',
    "role" : '리더',
    "constraint" : false,
    "isalive" : true
}
var userList = [obj1], phase = 1, target, answer;



client.on('ready', function(){
    console.log("I am ready");
    //console.log(client.message.author.username);
});

client.on('message', function(message){
    //console.log(message.content);
    //console.log(prefix);

    if (!message.cleanContent.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).split(' ');
    const command = args.shift().toLowerCase();
    console.log(args);

	const user = message.author.id;

    if(command === 'q') {
    	if (phase == 1 && message.mentions.users.first()) {

	        const taggedUser = message.mentions.users.first();
	        console.log(taggedUser);
	        var mess = message.cleanContent.replace("!q ", "");
	        mess = mess.replace("@"+taggedUser.username, "");
	        console.log(mess);
	        var promise = new Promise(function(resolve, reject) {
	            var request = app.textRequest(mess, {
	                sessionId: user
	            });
	            request.on('response', function(response) {
	                console.log(response);
	                target = searchUser(taggedUser);
	                var accord, pass;
	                if (target) {
		                pass = true;
		                var _team, _role, _not;
		                switch (response.result.action) {
		                    case 'input.teamQ':
		                    	_team = response.result.parameters.Team;
		                        if (_team === 'A' || _team === 'B') {
		                        	if (target.team == response.result.parameters.Team) {
			                            accord = true;
			                        } else {
			                            accord = false;
			                        }
			                    } else {
			                    	pass = false;
			                    }
		                    break;
		                    case 'input.teamNotQ':
		                    	_team = response.result.parameters.Team;
		                    	_not = response.result.parameters.Not; 
		                        if ((_team === 'A' || _team === 'B') && _not === 'not') {
			                        if (target.team != response.result.parameters.Team) {
			                            accord = true;
			                        } else {
			                            accord = false;
			                        }
			                    } else {
			                    	pass = false;
			                    }
		                    break;
		                    case 'input.roleQ':
		                    	_role = response.result.parameters.Role;
		                        if (_role === '리더' || _role === '멤버') {
		                        	if (target.role == response.result.parameters.Role) {
			                            accord = true;
			                        } else {
			                            accord = false;
			                        }
			                    } else {
			                    	pass = false;
			                    }
		                    break;
		                    case 'input.roleNotQ':
		                        _role = response.result.parameters.Role;
		                    	_not = response.result.parameters.Not; 
		                        if ((_role === '리더' || _role === '멤버') && _not === 'not') {
		                        	if (target.role != response.result.parameters.Role) {
			                            accord = true;
			                        } else {
			                            accord = false;
			                        }
			                    } else {
			                    	pass = false;
			                    }
		                    break;
		                    default:
		                        accord = false;
		                        pass = false;
		                    break;
		                }

		                if (pass) {
			                if (accord == target.constraint) {
			                	answer = true;
			                } else {
			                	answer = false;
			                }
			                message.channel.send({embed: {
								color: 3447003,
								author: {
								    name: message.mentions.users.first().username,
								    icon_url: message.mentions.users.first().avatarURL
								},
								title: "Q.",
								description: mess,
							}});

			                message.channel.send('<@!' + target.id + '>, 대답을 해주세요.');
			                message.delete();
			                phase = 2;
		            	} else {
		            		if (response.result.action == 'input.teamNotNotQ' || response.result.action == 'input.roleNotNotQ') {
		            			message.channel.send(message.author.username + ", 부정을 이중 이상으로 사용하지 말아주십시오.");
		            		} else {
		            			message.channel.send(message.author.username + ", 질문을 인식하지 못했습니다.");
		            		}
		            		message.delete();
		            	}
	            	} else {
		            	message.channel.send(message.author.username + ", "+ message.mentions.users.first().username +"은(는) 잘못된 대상입니다.")
		            	message.delete();
		            }
	            });

	            request.on('error', function(error) {
	                resolve(null);
	            });

	            request.end();
	        });

	        (async function(){
	            var result = await promise;
	            if(result){
	                message.reply(result);
	            } else{
	                message.channel.send(message.author.username + ", 잘못된 입력입니다.");
	                message.delete();
	            }
	        }());
    	} else {
    		if (phase != 1)
    			message.channel.send(message.author.username + ", 질문을 할 차례가 아닙니다.");
    		else
    			message.channel.send(message.author.username + ", 잘못된 입력입니다.");
    		message.delete();
    	}
    }

    if(command === 'a') {
    	console.log(target);
    	console.log(phase);
    	if ((phase == 2) && (user == target.id)) {
	        var mess = message.cleanContent.replace("!a ", "");
	        console.log(mess);
	        var promise = new Promise(function(resolve, reject) {
	            var request = app.textRequest(mess, {
	                sessionId: user
	            });
	            request.on('response', function(response) {
	            	console.log(response);
	                var pass, resp;
	                if (response.result.action == "input.A") {
	                	pass = true;
	                	if (response.result.parameters.Answer == "true") {
	                		resp = true;
	                	} else if (response.result.parameters.Answer == "false") {
	                		resp = false;
	                	} else {
	                		pass = false;
	                	}
	                } else {
	                	pass = false;
	                }
	                if (pass) {
	                	message.channel.send({embed: {
							color: 3447003,
							author: {
							    name: message.author.username,
							    icon_url: message.author.avatarURL
							},
							title: "A.",
							description: mess,
						}});
	                	if (answer == resp) {
	                		message.channel.send(message.author.username + ", 올바른 답변입니다.");
	                	} else {
	                		message.channel.send(message.author.username + ", 잘못된 답변입니다.");
	                		// 패널티 부과
	                	}
	                	message.delete();
	                	phase = 1;
	                } else {
	                	message.channel.send(message.author.username + ", 답변을 인식하지 못했습니다.");
	                	message.delete();
	                }
	            });

				request.on('error', function(error) {
	                resolve(null);
	            });

	            request.end();
	        });

	        (async function(){
	            var result = await promise;
	            if(result){
	                message.reply(result);
	            } else{
	                message.channel.send(message.author.username + ", 잘못된 입력입니다.");
	                message.delete();
	            }
	        }());
	    } else {
	    	if (phase == 2) {
	    		message.channel.send(message.author.username + ", 당신이 답변할 차례가 아닙니다.");
	    	} else {
	    		message.channel.send(message.author.username + ", 답변을 할 차례가 아닙니다.");
	    	}
	    	message.delete();
	    }
    }
});


function remove(username, text){
    return text.replace("@" + username + " ", "");
}

function searchUser(target){
    for (var i = 0; i < userList.length; i++) {
        if (userList[i].id == target.id) {
            return userList[i];
        }
    }
    return false;
}

client.login(config.token);