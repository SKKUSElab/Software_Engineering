
const Init = require("./init.js");
//this function is used whenever a userlist is updated.
// this function have two parameter(gamelist, channel_id) and return two values, 
// first value means a value that includes end or continue ( continue : 0, end : 1)
// second value means winner team ( 'A' or 'B');
function checkEndCondition(_gamelist, _channel_id) {
	var userlist = _gamelist.getUserlist(_channel_id);
	var endc = 0;
	team = null;
	
	userlist.forEach(function(user, key, array) {
		if(user.role == "리더" && user.isalive === false) {
			console.log(`user.role = ${user.role}, user.isalive = ${user.isalive}, ${user.team}`);
			if(user.team == 'A') {
				endc = 1;
				team = 'B';
				console.log(`if user = a ${endc}, ${team}`);
			}
			else if(user.team == 'B') {
				endc = 1;
				team = 'A';
				console.log(`if user b ${endc}, ${team}`);
			}
		}
	});
	console.log(`return ${endc}, ${team}`);
	return [endc, team];
}
function end(_gamelist, _channel_id) {
	var userlist = _gamelist.getUserlist(_channel_id);
	var newgamelist = _gamelist;
	newgamelist.remove(_channel_id);
	
	return newgamelist;
}

module.exports = {
		checkEndCondition : checkEndCondition,
		end : end
};
