const Discord = require('discord.js');


// used to create gamelist
function createGameList() {
	var gamelist = {};
	gamelist.status = {};				// 0 : before start or terminated 1 : being in game 2 : QnA or 지목 상태  3 : 답변을 기다리는 상
	gamelist.userlist = {};
	gamelist.target = {};// 답변해야 되는 사람들을 넣어놓는 변수 - 작성중
	gamelist.answer = {};
	gamelist.getKey  = function(channel_id) {
		return channel_id;
	};
	
	//	put key : channel_id(string), value : userlist(array)
	gamelist.put = function(channel_id, userlist) {
		var key = gamelist.getKey(channel_id);
		gamelist.status[key] = 1;
		gamelist.userlist[key] = userlist;	
	};
	gamelist.contains = function(channel_id) {
		var key = gamelist.getKey(channel_id);
		if(gamelist.userlist[key]) {
			return true;
		} else {
			return false;
		}
	};
	gamelist.setStatus = function(channel_id, _status) {
		gamelist.status[channel_id] = _status;
	};
	
	gamelist.getStatus = function(channel_id) {
		return gamelist.status[channel_id];
	};
	
	gamelist.getUserlist = function(channel_id) {
		var key = gamelist.getKey(channel_id);
		if(gamelist.userlist[key]) {
			return gamelist.userlist[key];
		}
		return null;
	};
	gamelist.remove = function(channel_id) {
		var key = gamelist.getKey(channel_id) ;
		if(gamelist.contains(channel_id)) {
			gamelist.setStatus[key] = 0;
			gamelist.userlist[key] = undefined;
		}
	};
	gamelist.checkGameStatus = function (channel_id) {
		var status = gamelist.getStatus(channel_id);
		var msg;
		switch(status) {
		case 0 : 
			msg = {
				status : 0,
				msg : "this channel is not in game "
			};
			break;
		
		case 1: 
			msg = {
					status : 1,
					msg : "this channel is in game "
				};
			break;
		
		case 2: 
			msg = {
					status : 2,
					msg : "this game is waiting for answer about the question."
				};
			break;
		
		case 3:
			msg = {
				status : 3,
				msg : "this game is waiting for answer about the question."
			};
			break;
		}
		return msg;
	}
	
	gamelist.pushAnswer = function(_channel_id, user){	// 답변해야 되는 사람을 넣는 함수 - 작성중
		
	}
	
	return gamelist;
}

// this function assign role, constraint, etc to users, and then return userlist.
function getRandom(min, max) {
	  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function assign(members, botid, alive, client) {
	const constraint  = [0 ,1];	 // 0 : 거짓말만 | 1 : 진실만 | 2 : 거짓말 그리고 진실 둘다 사용 가능.
	const team = ["A", "B"];
    const role = {kingA : 0, kingB : 0};
    
	var userlist = [];
	var mem_id = "";
	for (var i = members.length - 1; i >= 0; i--) {
        j = getRandom(0, members.length-1); 
        var temp = members[i];
        members[i] = members[j];
        members[j] = temp;
    }
	
	// console.log(" \n alive : " + alive.has(members[0].toString().slice(3, -1)) + '\n');
    for(var j = members.length -1; j >= 0; j-- ) {
    	mem_id = members[j].id;
    	if(!(alive.has(mem_id))) {
    		continue;
    	}
    	if(mem_id == botid){
    		continue;
    	}
    	
    	// console.log(" hi :  : : ;: " + members[i].toString().slice(3, -1));
	//	console.log("alive" + mem_id);
		console.log("alive : " + mem_id + " status : " + alive.get(mem_id).status);
    	if(alive.get(mem_id).status != 'online')
    		continue;
    	
    	if(role.kingA === 0 ) {
    		role.kingA = 1;
    		ro = "리더";
    		te = "A";
    	}
    	else  if(role.kingB === 0) {
    		role.kingB = 1;
    		ro = "리더";
    		te = "B";
    	}
    	else {
    		ro = "멤버";
    		te = team[j%2];
    	}
    	
    	co = constraint[j%2];
    	var userInfo = {};
    	userInfo = {
			  id : "<@" + mem_id +">",
			  mem_id : mem_id,
			  role : ro,
			  team : te,
			  constraint : co,
			  isalive : true			// 1 : alive , 0 : death
    	};
    	console.log("mem_id: " + userInfo.mem_id + "\n");
     	console.log(" v : " + userInfo.id + '\n');
    	userlist.push(userInfo);
    }
    console.log("============userlist : " + userlist);
    
    userlist.forEach(function(item, index, array){
    	member = getmember(item, members);
    	console.log(`*****member = ${member}`);
    	var constraints;
    	if(item.constraint == 0){
    		constraints = "당신은 거짓말만 할 수 있습니다. ";
    	}else if(item.constraint == 1){
    		constraints = "당신은 참말만 할 수 있습니다. ";
    	}
    	console.log(item);
    	
    	member.send({embed: {
    	    color: 3447003,
    	    author: {
    	      name: client.user.username,
    	      icon_url: client.user.avatarURL
    	    },
    	    title: "프로필",
    	    description: "당신의 팀, 지위, 제약조건 정보입니다.",
    	    fields: [{
    	        name: "팀",
    	        value: item.team
    	      },
    	      {
    	        name: "역할",
    	        value: item.role
    	      },
    	      {
    	        name: "제약조건",
    	        value: constraints
    	      }
    	    ],
    	    timestamp: new Date(),
    	    footer: {
    	      icon_url: client.user.avatarURL,
    	      text: "from your Mob."
    	    }
    	  }
    	});
//    	promise = new promise(function(){
//    		member.createDM
//    	});
//    	(async function(){
//    		dmchannel = await promise;
//        	console.log(dmchannel);
//        	dmchannel.send(`Role: ${item.role}, Team: ${item.team}`);
//    	});
    	
    });
    
    return userlist;
}

function getmember(_member, _members){
	var member;
	_members.forEach(function (item, index, array){
		console.log(`^^^^${item.id}, ${_member.mem_id}`);
		if(item.id == _member.mem_id){
			member = item;
		}
	})
	return member;
}


// if user-info.s to be established have correspond to user-info.s established in DB, take their from DB and then set up userlist. 
function init(members) {	
	
}

module.exports = {
		gamelist : createGameList,
		assign : assign
};
 