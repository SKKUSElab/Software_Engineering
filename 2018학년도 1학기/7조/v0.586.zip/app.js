/*jshint esversion: 6 */

// Load up the discord.js library
const Discord = require("discord.js");
//const QnA = require("./qna.js");
const Elimination = require("./elimination.js");
const Init = require("./init.js");
const end = require("./end.js");
var apiai = require('apiai');


const leader = "리더";
const member = "멤버";

var gamelist = Init.gamelist();

// This is your client. Some people call it `bot`, some people call it `self`,
// some might call it `cootchie`. Either way, when you see `client.something`,
// or `bot.something`,
// this is what we're refering to. Your client.
const client = new Discord.Client();

// Here we load the config.json file that contains our token and our prefix
// values.
const config = require("./config.json");
var app = apiai(config.Dialogflow);
// config.token contains the bot's token
// config.prefix contains the message prefix.

client.on("ready", () => {
  // This event will run if the bot starts, and logs in, successfully.
  console.log(`Bot has started, with ${client.users.size} users, in ${client.channels.size} channels of ${client.guilds.size} guilds.`); 
  // Example of changing the bot's playing game to something useful.
	// `client.user` is what the
  // docs refer to as the "ClientUser".
  client.user.setActivity(`Serving ${client.guilds.size} servers`);
});

client.on("guildCreate", guild => {
  // This event triggers when the bot joins a guild.
  console.log(`New guild joined: ${guild.name} (id: ${guild.id}). This guild has ${guild.memberCount} members!`);
  client.user.setActivity(`Serving ${client.guilds.size} servers`);
});

client.on("guildDelete", guild => {
  // this event triggers when the bot is removed from a guild.
  console.log(`I have been removed from: ${guild.name} (id: ${guild.id})`);
  client.user.setActivity(`Serving ${client.guilds.size} servers`);
});


client.on("presenceUpate", ( oldMember, newMember) => {
	//this event triggers when the bot has recognized the status of members.
	 if(newMember.presence.status == 'offline'){
		 var channel_id = newMember.lastMessage.channel.toString();
		 console.log(channel_id);
		 var list = gamelist.get(channel_id);
		 list.forEach(function (item, key, array) {
			if(item.id == newMember.toString()){
				item.isalive = death;
				console.log(item.id + "가 나가서 죽음으로 인식합니다.");
				
				gamelist.remove(channel_id);
				gamelist.put(channel_id, list);
			}
		 })
	 }
})



client.on("message", async message => {
  // This event will run on every single message received, from any channel or
	// DM.
  
  // It's good practice to ignore other bots. This also makes your bot ignore
	// itself
  // and not get into a spam loop (we call that "botception").
  if(message.author.bot) return;
  
  // Also good practice to ignore any message that does not start with our
	// prefix,
  // which is set in the configuration file.
  if(message.content.indexOf(config.prefix) !== 0) return;
  
  // Here we separate our "command" name, and our "arguments" for the command.
  // e.g. if we have the message "+say Is this the real life?" , we'll get the
	// following:
  // command = say
  // args = ["Is", "this", "the", "real", "life?"]
  const args = message.content.slice(config.prefix.length).trim().split(/ +/g);
  const command = args.shift().toLowerCase();
  
  // Let's go with a few common example commands! Feel free to delete or
	// change those.
  
  if(command === 'start') {
	  
	  
	  
	  var usrs = message.channel.members.array();
	  var list =[];
	  usrs.forEach(function (item, key, mapObj) {
		  list = mapObj;
		  return;
	  });
	  console.log(list+ "\n\n");
	  console.log(`#####id : ${list[0].id}`);
	  var botid = client.user.id;
	  var alive =  message.channel.guild.presences;
	  var userlist ;
	  var channel_id = message.channel.toString();
	  
	  //console.log("botid : " + botid +  "\n alive : " + alive + "\n userlits : " +  userlist + "\n channel_id : " + channel_id);
	  
	  //console.log("\n userlits : " +  userlist[0].id + "\n channel_id : " + channel_id);
	  //console.log("=====it checks whether it create user-list below.=============\n");
	  //if(Array.isArray(userlist)) {
		  if (gamelist.contains(channel_id)&&gamelist.getStatus(channel_id)) {
			  message.channel.send("현재 채널에서는 게임이 시작 중입니다. 같은 채널에서 게임을 중복해서 사용하실 수 없습니다.");
		  }
		  else {
			  userlist = Init.assign(list, botid, alive, client);
			  message.channel.send({embed: {
				    color: 3447003,
				    author: {
				      name: client.user.username,
				      icon_url: client.user.avatarURL
				    },
				    title: "게임을 시작하겠습니다.",
				    
				    description: "게임 시작하기에 앞서, 간단히 설명하겠습니다.",
				    fields: [{
				        name: "하나",
				        value: "당신은 개인 메시지로 자신의 역할, 팀, 게임을 함에 있어서 제약이 될 조건 등을 받았을 것입니다."
				      },
				      {
				        name: "둘",
				        value: "게임을 할 시에 제약 조건에 따라 게임을 진행 해 주시기 바랍니다."
				      },
				      {
				        name: "승리 조건 ",
				        value: "자유로운 대화와 게임 내에서 사회자에게 질문을 통해 상대방의 왕을 추리하여 지목을 통해 제거하시면 승리합니다. \n" +
				        		"단 왕이 아닌 다른 사람을 지목 시 자신이 죽을 수 있습니다."
				      },
				      {
				          name: "사회자에게 명령하는 용어",
				          value: "질 문 : !q @유저 질문 \n" + "대 답 : !a 대답\n" + "지 목 : !e @유저"
				        },
				      
				    ],
				    timestamp: new Date(),
				    footer: {
				      icon_url: client.user.avatarURL,
				      text: "사회자"
				    }
				  }
				});
			  message.channel.send("게임 준비가 완료되었습니다. \n");
			  var trueteam = 0;
			  var falseteam = 0;
			  userlist.forEach(function(item, index, array){
				  if(item.constraint == 0){
					  falseteam++;
				  }else if(item.constraint == 1){
					  trueteam++;
				  }
			  });
			  message.channel.send(`참만 만하는 사람: ${trueteam}명, 거짓만 말하는 사람: ${falseteam}`);

			  gamelist.put(channel_id, userlist);
			  console.log("=============\n");
		  }
	  //}
	  
	  
	  
  }
  
  if(command === "help" || command === "h"){
	  message.channel.send({embed: {
		    color: 3447003,
		    author: {
		      name: client.user.username,
		      icon_url: client.user.avatarURL
		    },
		    title: "안녕하세요? 마피아 봇입니다.~~!",
		    
		    description: "저의 사용법, 즉 명령어를간단히 설명하겠습니다.",
	    fields: [{
				name : "게임 룰 설명",
				value :  "게임의 목표는 상대방 팀의 리더를 제거하는 것이 목표 입니다. " +
						" \n초기에 게임이 시작이 될 때, 각자의 역할과 제약조건 등을 개임 메시지로 배정을 받을 것입니다. " +
						"그 내용을 잘 숙지해주시고 게임을 진행해야합니다. \n 게임이 시작이 될 때, 자유로운 대화를 하게 되고, " +
						"명령어 (!q : 질문, !a 답변, !e : 지목)로 지목을 할 시에 잘못된 지목의 횟 수 한 번으로, 2번 이상의 잘못된 리더 " +
						"지목 시 패널티로 죽음이 주어집니다. \n 또한 사회자에게 질문을 할 수 있는데, 누군가에게  질의를 사회를 통해서 " +
						"할 수 있습니다. \n 사회자는 이 질문이 상대방의 제약조건에 따라 잘못된 답변을 할 시에 죽음이 주어집니다. 	\n 질문" +
						" 중에는 다른 질문 또는 자유로운 대화가 제한되어 집니다."
						
		         },
		       {
		        name: "!start",
		        value: "이 명령어를 게임을 시작을 하기 위해 사용합니다."
		      },
		      {
		        name: "!e @대상 네임",
		        value: "상대방이 왕인지 생각이 될 때, 지목하여 제거하기 위한 명령어입니다."
		      },
		      {
		        name: "!q @대상 질문",
		        value: "대상을 지정하고 이에 질문을 하면 입력하시면 됩니다."
		      },
		      {
		          name: "!a 답변",
		          value: "질문에 대해 답변을 하기위해 사용합니다."
		        },
		      { name : "!help",
			value : "이 메시지를 다시 보려면 다음을 누르시면 됩니다."
		      
		      }],
		    timestamp: new Date(),
		    footer: {
		      icon_url: client.user.avatarURL,
		      text: "© Example"
		    }
		  }
		});
  }
  
  if(command === "ping") {
    // Calculates ping between sending a message and editing it, giving a nice
	// round-trip latency.
    // The second ping is an average latency between the bot and the websocket
	// server (one-way, not round-trip)
    const m = await message.channel.send("Ping?");
    m.edit(`Pong! Latency is ${m.createdTimestamp - message.createdTimestamp}ms. API Latency is ${Math.round(client.ping)}ms`);
  }
  
  if(command === "say") {
    // makes the bot say something and delete the message. As an example, it's
	// open to anyone to use.
    // To get the "message" itself we join the `args` back into a string with
	// spaces:
    const sayMessage = args.join(" ");
    // Then we delete the command message (sneaky, right?). The catch just
	// ignores the error with a cute smiley thing.
    message.delete().catch(O_o=>{}); 
    // And we get the bot to say the thing:
    message.channel.send(sayMessage);
  }
  
  if(command === "kick") {
    // This command must be limited to mods and admins. In this example we just
	// hardcode the role names.
    // Please read on Array.some() to understand this bit:
    // https://developer.mozilla.org/en/docs/Web/JavaScript/Reference/Global_Objects/Array/some?
    if(!message.member.roles.some(r=>["Administrator", "Moderator"].includes(r.name)) )
      return message.reply("Sorry, you don't have permissions to use this!");
    
    // Let's first check if we have a member and if we can kick them!
    // message.mentions.members is a collection of people that have been
	// mentioned, as GuildMembers.
    // We can also support getting the member by ID, which would be args[0]
    let member = message.mentions.members.first() || message.guild.members.get(args[0]);
    if(!member)
      return message.reply("Please mention a valid member of this server");
    if(!member.kickable) 
      return message.reply("I cannot kick this user! Do they have a higher role? Do I have kick permissions?");
    
    // slice(1) removes the first part, which here should be the user mention or
	// ID
    // join(' ') takes all the various parts to make it a single string.
    let reason = args.slice(1).join(' ');
    if(!reason) reason = "No reason provided";
    
    // Now, time for a swift kick in the nuts!
    await member.kick(reason)
      .catch(error => message.reply(`Sorry ${message.author} I couldn't kick because of : ${error}`));
    message.reply(`${member.user.tag} has been kicked by ${message.author.tag} because: ${reason}`);

  }
  
  if(command === "ban") {
    // Most of this command is identical to kick, except that here we'll only
	// let admins do it.
    // In the real world mods could ban too, but this is just an example, right?
	// ;)
    if(!message.member.roles.some(r=>["Administrator"].includes(r.name)) )
      return message.reply("Sorry, you don't have permissions to use this!");
    
    let member = message.mentions.members.first();
    if(!member)
      return message.reply("Please mention a valid member of this server");
    if(!member.bannable) 
      return message.reply("I cannot ban this user! Do they have a higher role? Do I have ban permissions?");

    let reason = args.slice(1).join(' ');
    if(!reason) reason = "No reason provided";
    
    await member.ban(reason)
      .catch(error => message.reply(`Sorry ${message.author} I couldn't ban because of : ${error}`));
    message.reply(`${member.user.tag} has been banned by ${message.author.tag} because: ${reason}`);
  }
  
  if(command === "purge") {
    // This command removes all messages from all users in the channel, up to
	// 100.
    
    // get the delete count, as an actual number.
    const deleteCount = parseInt(args[0], 10);
    
    // Ooooh nice, combined conditions. <3
    if(!deleteCount || deleteCount < 2 || deleteCount > 100)
      return message.reply("Please provide a number between 2 and 100 for the number of messages to delete");
    
    // So we get our messages, and delete them. Simple enough, right?
    const fetched = await message.channel.fetchMessages({limit: deleteCount});
    message.channel.bulkDelete(fetched)
      .catch(error => message.reply(`Couldn't delete messages because of: ${error}`));
  }
  
  if(command === "guild") {
	  return message.reply(`This is ${message.guild}`);
  }
  
  if(command === "member" || command === "members") {
	  
	  UserList.forEach(function(item, index, array){
		  message.channel.send(`members: ${item.id}`);
		  console.log(`${item.toString()}`);
	  })
	  
	  return message.channel.send(`That would be all, sir!`);
	 
  }
  
  if(command === 'q') {
	  phase = gamelist.getStatus(message.channel.toString());
	  
  	if (phase == 1 && message.mentions.users.first()) {

	        const taggedUser = message.mentions.users.first();
	        console.log(taggedUser);
	        var mess = message.cleanContent.replace("!q ", "");
	        mess = mess.replace("@"+taggedUser.username, "");
	        console.log(mess);
	        var promise = new Promise(function(resolve, reject) {
	            var request = app.textRequest(mess, {
	                sessionId: message.author.id
	            });
	            request.on('response', function(response) {
	                console.log(response);
	                target = searchUser(taggedUser, message.channel.toString());
	                gamelist.target[message.channel.toString()] = target;
	                var accord, pass;
	                if (target) {
		                pass = true;
		                var _team, _role, _not;
		                switch (response.result.action) {
		                    case 'input.teamQ':
		                    	_team = response.result.parameters.Team;
		                        if (_team === 'A' || _team === 'B') {
		                        	if (target.team == response.result.parameters.Team) {
			                            accord = true;
			                        } else {
			                            accord = false;
			                        }
			                    } else {
			                    	pass = false;
			                    }
		                    break;
		                    case 'input.teamNotQ':
		                    	_team = response.result.parameters.Team;
		                    	_not = response.result.parameters.Not; 
		                        if ((_team === 'A' || _team === 'B') && _not === 'not') {
			                        if (target.team != response.result.parameters.Team) {
			                            accord = true;
			                        } else {
			                            accord = false;
			                        }
			                    } else {
			                    	pass = false;
			                    }
		                    break;
		                    case 'input.roleQ':
		                    	_role = response.result.parameters.Role;
		                        if (_role === '리더' || _role === '멤버') {
		                        	if (target.role == response.result.parameters.Role) {
			                            accord = true;
			                        } else {
			                            accord = false;
			                        }
			                    } else {
			                    	pass = false;
			                    }
		                    break;
		                    case 'input.roleNotQ':
		                        _role = response.result.parameters.Role;
		                    	_not = response.result.parameters.Not; 
		                        if ((_role === '리더' || _role === '멤버') && _not === 'not') {
		                        	if (target.role != response.result.parameters.Role) {
			                            accord = true;
			                        } else {
			                            accord = false;
			                        }
			                    } else {
			                    	pass = false;
			                    }
		                    break;
		                    default:
		                        accord = false;
		                        pass = false;
		                    break;
		                }

		                if (pass) {
			                if (accord == target.constraint) {
			                	answer = true;
			                } else {
			                	answer = false;
			                }
			                message.channel.send({embed: {
								color: 3447003,
								author: {
								    name: message.mentions.users.first().username,
								    icon_url: message.mentions.users.first().avatarURL
								},
								title: "Q.",
								description: mess,
							}});

			                message.channel.send(target.id + ', 대답을 해주세요.');
			                message.delete();
			                phase = 2;
			                gamelist.setStatus(message.channel.toString(), phase);
			                gamelist.answer[message.channel.toString()] = answer;
		            	} else {
		            		if (response.result.action == 'input.teamNotNotQ' || response.result.action == 'input.roleNotNotQ') {
		            			message.channel.send(message.author.username + ", 부정을 이중 이상으로 사용하지 말아주십시오.");
		            		} else {
		            			message.channel.send(message.author.username + ", 질문을 인식하지 못했습니다.");
		            		}
		            		message.delete();
		            	}
	            	} else {
		            	message.channel.send(message.author.username + ", "+ message.mentions.users.first().username +"은(는) 잘못된 대상입니다.")
		            	message.delete();
		            }
	            });

	            request.on('error', function(error) {
	                resolve(null);
	            });

	            request.end();
	        });

	        (async function(){
	            var result = await promise;
	            if(result){
	                message.reply(result);
	            } else{
	                message.channel.send(message.author.username + ", 잘못된 입력입니다.");
	                message.delete();
	            }
	        }());
  	} else {
  		if (phase != 1)
  			message.channel.send(message.author.username + ", 질문을 할 차례가 아닙니다.");
  		else
  			message.channel.send(message.author.username + ", 잘못된 입력입니다.");
  		message.delete();
  	}
  }
  
  if(command === 'a') {
  	console.log(target);
  	console.log(phase);
  	target = gamelist.target[message.channel.toString()];
  	answer = gamelist.answer[message.channel.toString()];
  	phase = gamelist.getStatus(message.channel.toString());
  	user = message.author;
  	
  	if ((phase == 2) && (user.id == target.mem_id)) {
	        var mess = message.cleanContent.replace("!a ", "");
	        console.log(mess);
	        var promise = new Promise(function(resolve, reject) {
	            var request = app.textRequest(mess, {
	                sessionId: user.id
	            });
	            request.on('response', function(response) {
	            	console.log(response);
	                var pass, resp;
	                if (response.result.action == "input.A") {
	                	pass = true;
	                	if (response.result.parameters.Answer == "true") {
	                		resp = true;
	                	} else if (response.result.parameters.Answer == "false") {
	                		resp = false;
	                	} else {
	                		pass = false;
	                	}
	                } else {
	                	pass = false;
	                }
	                if (pass) {
	                	message.channel.send({embed: {
							color: 3447003,
							author: {
							    name: message.author.username,
							    icon_url: message.author.avatarURL
							},
							title: "A.",
							description: mess,
						}});
	                	if (answer == resp) {
	                		message.channel.send(message.author.username + ", 올바른 답변입니다.");
	                	} else {
	                		message.channel.send(message.author.username + ", 잘못된 답변입니다.");
	                		// 패널티 부과
	                		UserList = gamelist.getUserlist(message.channel.toString());
	                		UserList.forEach(function(item, index, array){
	            				if(item.mem_id == message.author.id){
	            					item.isalive = false;
	            					var co;
	            					if(item.constraint == 0){
	            						co = "거짓";
	            					}else if(item.constraint == 1){
	            						co = "참";
	            					}
	            					message.channel.send(`팀 ${item.team} ${message.author}, 당신은 죽었습니다. RIP\n당신은 ${co}만을 말해야 했습니다.`);
	            				}
	            			})
	            			gamelist.put(message.channel.toString(), UserList);
	                		endgame(gamelist, message.channel.toString(), message);
	                	}
	                	message.delete();
	                	phase = 1;
	                	gamelist.setStatus(message.channel.toString(), phase);
	                } else {
	                	message.channel.send(message.author.username + ", 답변을 인식하지 못했습니다.");
	                	message.delete();
	                }
	            });

				request.on('error', function(error) {
	                resolve(null);
	            });

	            request.end();
	        });

	        (async function(){
	            var result = await promise;
	            if(result){
	                message.reply(result);
	            } else{
	                message.channel.send(message.author.username + ", 잘못된 입력입니다.");
	                message.delete();
	            }
	        }());
	    } else {
	    	if (phase == 2) {
	    		message.channel.send(message.author.username + ", 당신이 답변할 차례가 아닙니다.");
	    		console.log(`phase : ${phase}`);
	    	} else {
	    		message.channel.send(message.author.username + ", 답변을 할 차례가 아닙니다.");
	    		console.log(`phase : ${phase}`);
	    	}
	    	message.delete();
	    }
  }
  
  
//  if(command === "q" || command === "question" || command === "a", command === "answer") {
//	  const QnAquery = args.join(" ");
//	  var _channel_id = message.channel.toString();
//	  var _UserList = gamelist.getUserlist(_channel_id);
//	  if(gamelist.getStatus(_channel_id) == 1){
//		  gamelist.setStatus(_channel_id, 2);
//		  var p = new QnA(QnAquery, _UserList, message);
//		  const newStatus = p.question(message);
//		  gamelist.setStatus(_channel_id, newStatus);
//	  }else if(gamelist.getStatus(_channel_id) == 3){
//		  var p = new QnA(QnAquery, _UserList, message);
//		  const newStatus = p.answer(message);
//		  gamelist.setStatus(_channel_id, newStatus);
//	  }
//	  else {
//		  message.channel.send(gamelist.checkGameStatus(_channel_id).msg);
//	  }
//	  
//  }
  
  if(command === "userlist"){
	  var _channel_id = message.channel.toString();
	  var _UserList = gamelist.getUserlist(_channel_id);
	  if(_UserList == null){
		  message.channel.send(`게임중이 아닙니다. `);
	  }else{
	  _UserList.forEach(function(item, index, array){
		 message.channel.send(`${item.id}, 생존?: ${item.isalive}`); 
	  });
	  message.channel.send(", over");
	  }
  }
  
  if(command === "e" || command === "eli" || command === "eliminate" || command === "elimination") {
	  const EliminationQuery = args.join("");
	  var _channel_id = message.channel.toString();
	  var UserList = gamelist.getUserlist(_channel_id);
	  var illegal = false;
	  UserList.forEach(function(item, index, array){
		  console.log("first: " + item.mem_id);
		  if(item.mem_id == message.author.id){
			  if(!item.isalive){
				  illegal = true;
			  }
		  }
	  });
	  if(illegal){
		  return message.channel.send("죽은 자는 말이 없다.");
	  }
	  if(gamelist.getStatus(_channel_id) == 1){
		  var p = new Elimination(EliminationQuery, UserList);
		  
		  //message.channel.send(`message sent by: ${message.author.tag}`);
		  
		  let member = message.mentions.members.first() || message.guild.members.get(args[0]);
		  if(!member)
			  return message.channel.send("유효한 멤버를 입력해주십시오.");
		  var found = false;
		  UserList = gamelist.getUserlist(_channel_id);
		  UserList.forEach(function(item, index, array) {
			  console.log(`item: ${item.mem_id}, ${item.id}, ${item.team}, target: ${member.id}, ${item.isalive}`);
			  if(item.mem_id == member.id && item.isalive === true){
				  console.log("yes");
				  return found = true;
			  }
		  });
		  
		  if(!found)
			  return message.channel.send("유효한 멤버를 입력해주십시오. \n멤버 리스트 보기: !userlist");
		    
		  var elimination = p.eliminate(message.author, member);
		  var deadman;
		  
		  UserList, deadman = elimination;
		  gamelist.userlist[message.channel.toString] = UserList; 
		  console.log(`${UserList[0].isalive}, ${deadman.id}`);
		  var authorteam;
		  UserList.forEach(function(item, index, array){
			  if(item.mem_id == message.author.id){
				  authorteam = item.team;
			  }
		  })
		  UserList.forEach(function(item, index, array) {
			  if(item.mem_id == message.author.id){
				  if(!item.isalive){
					  var co;
  					if(item.constraint == 0){
  						co = "거짓";
  					}else if(item.constraint == 1){
  						co = "참";
  					}
					  message.channel.send(`팀 ${item.team} ${message.author} 가 죽었습니다... 잘못 짚었습니다!\n당신은 ${co}만을 말했습니다.`);
				  }
			  }
			  if(item.mem_id == member.id){
				  if(!item.isalive)
					  var co;
					if(item.constraint == 0){
						co = "거짓";
					}else if(item.constraint == 1){
						co = "참";
					}
					  message.channel.send(`팀 ${item.team} ${member} 가 팀 ${authorteam} ${message.author} 에 의해 죽었습니다.\n${member}는 ${co}만을 말했습니다.`);
			  }
		  })
		  if(message.author == deadman){
				  message.channel.send(`${message.author} is dead... You picked the wrong guy, sir!`);
		  }
		  if(member == deadman){
				  message.channel.send(`${member} has been killed by ${message.author}`);
		  }
		  
		  endgame(gamelist, message.channel.toString(), message);
	  }
	  else {
		  message.channel.send(gamelist.checkGameStatus(_channel_id).msg);
	  }
	  
  }
  
  
});

function idtoid(id){
	return "<@!" + id + ">";
}

function endgame(_gamelist, _channel_id, message){
	var e1;
	e1= end.checkEndCondition(_gamelist, _channel_id);
	endc = e1[0];
	team = e1[1];
	console.log(`${endc}, ${team}`);
	if(endc == 1){
		console.log("jjjj");
		var teamwon = [];
		var teamlost = [];
		var userlist = _gamelist.getUserlist(_channel_id);
		userlist.forEach(function(item, index, array){
			if(item.team == e1[1]){
				teamwon.push(item.id);
			}else{
				teamlost.push(item.id);
			}
		});
		message.channel.send({embed: {
		    color: 3447003,
		    author: {
		      name: client.user.username,
		      icon_url: client.user.avatarURL
		    },
		    title: "GAME OVER",
		    
		    description: "게임이 끝났습니다!",
		    fields: [
			{
				name : "승리 팀",
				value : "멤버: " + teamwon.toString() + "\n"
		         },
		         
		    {
				name : "패배 팀",
				value : "멤버: " + teamlost.toString() + "\n"
	         },


		      {
		        name: "새 게임",
		        value: "!start 명령어를 입력해주세요."
		      }
		      
		    ],
		    timestamp: new Date(),
		    footer: {
		      icon_url: client.user.avatarURL,
		      text: "마피아 올림"
		    }
		  }
		});
		message.channel
		return gamelist = end.end(_gamelist, _channel_id);
	}
}

function remove(username, text){
    return text.replace("@" + username + " ", "");
}

function searchUser(target, channel_id){
	userList = gamelist.getUserlist(channel_id);
    for (var i = 0; i < userList.length; i++) {
        if (userList[i].mem_id == target.id) {
            return userList[i];
        }
    }
    return false;
}

client.login(config.token);
           