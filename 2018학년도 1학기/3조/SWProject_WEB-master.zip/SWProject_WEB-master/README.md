SWProject_WEB

커뮤니티 전반적인 작업내용입니다. spring 기반으로 만들었으며, apache tomcat 8.5.3.1 서버와 mysql db를 사용했습니다. WebContent의 index.jsp를 실행하면 test 가능합니다. WEB-INF 에 view를 위한 jsp 파일들과 서블릿 설정이 들어있으며 src에 스프링을 통한 커뮤니티 동작을 위한 패키지들이 포함되어있습니다.
