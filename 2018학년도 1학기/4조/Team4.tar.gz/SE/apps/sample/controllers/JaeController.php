<?php
namespace Sample\Controller;
//제일 밑 2개 action이 핵심이라 주석처리 했습니다.

use Slimvc\Core\Controller;
use Sample\Model\AdminModel;
use Sample\Model\OsuploadModel;
use Sample\Model\OpensourceModel;


class JaeController extends Controller
{
    public function actionUpload()
    {
        $this->getApp()->contentType('text/html');

        $data = array(
            'title' => 'It works!',
            'content' => 'Have fun with Slim framework in MVC way!'
        );

        $this->render("admin/fileUpload.phtml", $data);
    }
    public function actionIndex()
    {
        $this->getApp()->contentType('text/html');

        $data = array(
            'title' => 'It works!',
            'content' => 'Have fun with Slim framework in MVC way!'
        );

        $this->render("index/jae.phtml", $data);
    }
    public function actionSearch()
    {/*
        $data = array(
            'keyword' => !empty($_POST['keyword']) ? trim($_POST['keyword']) : null
        );*/

            $keyword = $_GET['keyword'];

        $data = array(
            'keyword' => $keyword
        );
        $this->render("search/search.phtml", $data);
    }

    public function actionloginSession()
    {
        session_start();
        $_SESSION['uid'] = $_POST['uid'];
        header("Location: http://13.209.85.47/admin/management");
        exit();
    /*
        $osuploadModel = new OsuploadModel();
        $logfile = LOG_PATH."jaelog.txt";
        try {
            $res = $osuploadModel->getUploads();
        } catch(\Exception $e) {
            error_log($e->getMessage(),3,$logfile);
        }
        $data = array(
            'datas' =>$res
        );
        $this->render("admin/management.phtml", $data);*/
    }
    public function actionManagement()
    {
        session_start();
        $osuploadModel = new OsuploadModel();
        $logfile = LOG_PATH."jaelog.txt";
        try {
            $res = $osuploadModel->getUploads();
        } catch(\Exception $e) {
            error_log($e->getMessage(),3,$logfile);
        }
        $data = array(
            'datas' =>$res
        );
        $this->render("admin/management.phtml", $data);
    }
    public function actionAdminSignin()
    {
        $data = array(
            'keyword' => 'keyword',
            'content' => 'Have fun with Slim framework in MVC way!'
        );
        $this->render("admin/adminSignin.phtml", $data);
    }

    public function actionLoginProceed() {
        $email = $_POST['email'];
        $password = $_POST['password'];


        $adminModel = new AdminModel();

        $result = $adminModel->getVerificationByEmail(array('email'=>$email));

        if(!$result) {
            $res = array(
                'result' => 'FALSE',
                'msg' => 'Email dosen\'t exist.'
            );
        } else {
            if(!password_verify($password, $result['password'])) {
                $res = array(
                    'result' => 'FALSE',
                    'msg' => 'Password doesn\'t match.'
                );
            } else {
                $res = array(
                    'result' => 'TRUE',
                    'UID' => $result['uid'],
                );
            }
        }

        echo json_encode($res, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
    public function actionuploadModify() {
        $logfile = LOG_PATH."jaelog.txt";
        $id = !empty($_POST['id']) ? trim($_POST['id']) : null;
        $url = !empty($_POST['url']) ? trim($_POST['url']) : null;
        $name = !empty($_POST['name']) ? trim($_POST['name']) : null;
        $licence = !empty($_POST['licence']) ? trim($_POST['licence']) : null;
        $description = !empty($_POST['description']) ? trim($_POST['description']) : null;

        $osuploadModel = new OsuploadModel();
        $data = array(
            'id' => $id,
            'url' => $url,
            'name' => $name,
            'licence' => $licence,
            'description' => $description
        );
        try {
            $osuploadModel->updateOsuploadByID($data);
        } catch(\Exception $e) {
            error_log($e->getMessage(),3,$logfile);
        }
    }
    public function actionuploadDelete() {
        $logfile = LOG_PATH."jaelog.txt";
        $id = !empty($_POST['id']) ? trim($_POST['id']) : null;

        $osuploadModel = new OsuploadModel();
        $data = array(
            'id' => $id
        );
        try {
            $osuploadModel->deleteOsuploadByID($data);
        } catch(\Exception $e) {
            error_log($e->getMessage(),3,$logfile);
        }
    }

    public function actionuploadConfirm() {//사용자가 제시한 오픈소스를 관리자가 confirm하면 불린다.
        $logfile = LOG_PATH."jaelog.txt";
        $osuploadid = !empty($_POST['osuploadid']) ? trim($_POST['osuploadid']) : null;
        $name = !empty($_POST['name']) ? trim($_POST['name']) : null;

        $opensourceModel = new OpensourceModel();//오픈소스를 데이터베이스 관리하는 모델
        $osuploadModel = new OsuploadModel();//사용자가 올린 오픈소스를 임시로 보관하는 데이터베이스 관리하는 모델
        $data = array(
            'id' => $osuploadid,
            'name' => $name
        );
        $osuploadvalues = $osuploadModel->getOsuploadByID($data);
        try {
            $osAlreadyExists = $opensourceModel->getOpensourceByName($data);
        } catch(\Exception $e) {
            error_log($e->getMessage(),3,$logfile);
        }

        if($osAlreadyExists){//올리려는 opensource가 이미 있으면 해당 오픈소스를 업데이트하고 없으면 새로운 항목을 만들어서 등록한다.
            $datas = array(
                'id' => $osAlreadyExists['ID'],
                'licence'=> $osuploadvalues['Licence'],
                'description'=> $osuploadvalues['Description'],
                'homeurl'=> $osuploadvalues['URL']
            );
            $opensourceModel->updateOpensourceByID($datas);
        }else{
            error_log("Doesnt Exists",3,$logfile);
            $datas = array(
                'name' => $osuploadvalues['Name'],
                'licence'=> $osuploadvalues['Licence'],
                'description'=> $osuploadvalues['Description'],
                'homeurl'=> $osuploadvalues['URL']
            );
            $opensourceModel->insertOpensource($datas);
        }
        $osuploadModel->deleteOsuploadByID($data);
    }

    public function actionfileUpload() {//관리자가 데이터베이스를 등록하면 서버의 public/sample/data/ 디렉토리에 올린다.
        header('Content-Type: application/json');

        $errors = false;


        $resp = array(
        );
        # Normal Response Code
        $logfile = LOG_PATH."jaelog.txt";
        if(function_exists('http_response_code')){

            if (!empty($_FILES)) {//올리는 파일이 없으면 실행

                $tempFile = $_FILES['file']['tmp_name'];          //3
                $targetFile =  FILEUPLOAD_PATH. $_FILES['file']['name'];  //5

                try {
                    move_uploaded_file($tempFile,$targetFile); //파일 업로드
                } catch(\Exception $e) {
                    error_log($e->getMessage(),3,$logfile);
                    exit();
                }
                //업로드한 파일을 insertFromTxt.py로 Opensource데이터베이스에 업로드한다.
                $page = 'python3 /var/www/OS3/public/sample/data/insertFromTxt.py '.$_FILES['file']['name'];
                //quotemeta($page);
                $pageresult=array();
                $npage="";
                exec($page,$pageresult,$npage);
            }

            http_response_code(200);
        }


        # On Error
        if($errors)
        {
            if(function_exists('http_response_code'))
                http_response_code(400);

            $resp['error'] = "Couldn't upload file, reason: ~";
        }

        echo json_encode($resp);
    }
}
