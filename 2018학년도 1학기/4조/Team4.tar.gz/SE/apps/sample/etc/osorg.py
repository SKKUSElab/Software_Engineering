import requests
import sys
from bs4 import BeautifulSoup

#opensource org article crawling -> merged with wiki.py to pagethread.py
url = sys.argv[1]
url = requests.get(url)
c= url.content

clist = BeautifulSoup(c,"html.parser")

clist = clist.find_all("h3",{"class":"title"})

for i in range(len(clist)):
	clist[i] = clist[i].find("a")
	

j = 0
for i in clist:
    if(j >= 5):
        break
    print("<h4>",i,"</h4>")
    
    j+=1


