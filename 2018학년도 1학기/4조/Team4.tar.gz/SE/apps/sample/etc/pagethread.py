import requests
import sys
import threading
from bs4 import BeautifulSoup


#crawl data from wikipedia and opensource.org


def wiki(ret1):
    wikiurl = sys.argv[1]
    
    wikiurl = requests.get(wikiurl)
    c = wikiurl.content
    wcont = BeautifulSoup(c, "html.parser")
    wcont = wcont.find("div", {"class": "mw-parser-output"})
    wcont = wcont.find("p")
    for sup in wcont("sup"):
        wcont.sup.extract()
    wcont = wcont.get_text()
    wcont = wcont.encode('UTF8')
    wcont = wcont.decode('ascii', 'ignore')
    
    ret1.append(wcont)
    

def osorg(ret2):
    osorgurl = sys.argv[2]
    osorgurl = requests.get(osorgurl)
    cont = osorgurl.content
    clist = BeautifulSoup(cont, "html.parser")
    clist = clist.find_all("h3", {"class": "title"})
    for i in range(len(clist)):
        clist[i] = clist[i].find("a")

    ret2.append(clist)
    

presult1 = []
presult2 = []

th1 = threading.Thread(target=wiki,args=(presult1,))
th2 = threading.Thread(target=osorg,args=(presult2,))

th1.start()
th2.start()

th1.join()
th2.join()

print(presult1[0])

j=0
for i in presult2[0]:
    if (j >= 5):
        break
    print("<h4>"+str(i)+"</h4>")
    j += 1


