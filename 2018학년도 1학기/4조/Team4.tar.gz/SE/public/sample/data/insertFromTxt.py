# Heekang Park
# Last Modified : 2018.06.06.
# State : Working (Not completed)
#####################
# Explanation :
# Insert into the database with .txt file exported from the Opensource excel file written from SOSC
#####################
# Usage :
# 1. Give the file name into the commandline argument and run the program
# 2. Then required queries are automatically sended to the DB

import pymysql
import os
import sys

def isNumber(s):
	try:
		float(s)
		return True
	except ValueError:
		return False

def dequote(s):
	if len(s) == 0:
		return s
	if (s[0] == s[-1]) and s.startswith(("'", '"')):
		return s[1:-1]
	if s.startswith(("'", '"')):
		return s[1:]
	if s.endswith(("'", '"')):
		return s[:-1]
	return s

def PrintUsage():
    print("Usage : python3 " + sys.argv[0] + " [dir_of_txt_file]")

if (len(sys.argv) is 1) or (len(sys.argv) > 2):
    PrintUsage()
    sys.exit(1)

if os.path.isfile(sys.argv[1]):
    db_name = "opensource"
    conn = pymysql.connect(host='localhost', user='root', password='sogong1234', db=db_name, charset='utf8')
    curs = conn.cursor()

	with open(sys.argv[1], "r") as f:
		while True:
			line = f.readline()

			if not line:
				break

			line = line.split("\t")

			if not isNumber(line[0]):
				continue

			try:
				mCategoryTemp = dequote(line[1])
			except IndexError:
				print("problem in Category : " + str(line))
				continue

			if mCategoryTemp != "":
				mCategory = dequote(mCategoryTemp.replace("\n", ""))

			try:
				mName = dequote(line[2])
			except IndexError:
			    print("problem in Name : " + str(line))
			    continue

			try:
				mHomeURL = dequote(line[3])
			except IndexError:
			    print("problem in HomeURL : " + str(line))
			    continue

			try:
				mDescription = dequote(line[4])
			except IndexError:
			    print("problem in Description : " + str(line))
			    continue

			try:
				mLicence = dequote(line[5])
			except IndexError:
			    print("problem in Licence : " + str(line))
			    continue

			try:
				sql = "INSERT INTO Opensource(Name, AvgRating, NumOfRating, Licence, Description, HomeURL) VALUES (\"" + mName + "\", 0, 0, \"" + mLicence + "\", \"" + mDescription + "\", \"" + mHomeURL + "\")"
				curs.execute(sql)
				conn.commit()
			except:
				print("insert to Opensource failed : " + str(line))
				continue

			try:
				sql = "SELECT ID from Opensource where Name=\"" + mName + "\" AND Licence=\"" + mLicence + "\" AND Description=\"" + mDescription + "\" AND HomeURL=\"" + mHomeURL + "\" ORDER BY ID DESC"
				curs.execute(sql)
				result = curs.fetchall()
				ID = result[0][0]

				sql = "INSERT INTO Category(ID, Category) VALUES (" + str(ID) + ", \"" + mCategory + "\")"

				curs.execute(sql)
				conn.commit()
			except:
				print("insert to Category failed : " + str(line))

    conn.close()
else:
    PrintUsage()
    print("can't find the file")


