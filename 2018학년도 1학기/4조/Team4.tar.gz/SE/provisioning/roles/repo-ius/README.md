# Ansible Role: IUS Repository

Installs IUS Repository (http://iuscommunity.org/) for RHEL/CentOS

## Requirements

None.

## Role Variables

None.

## Example Playbook

    - hosts: servers
      roles:
        - { role: repo-ius }

## License

MIT Licence